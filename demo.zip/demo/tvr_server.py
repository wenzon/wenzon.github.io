﻿#coding=utf-8

import time
import urllib
import urllib2

import json
import hashlib
import base64

from BaseHTTPServer import BaseHTTPRequestHandler

class TVRHttpServer(BaseHTTPRequestHandler):
	def do_POST(self):
		do_GET(self)

	def do_GET(self):
		path, args = urllib.splitquery(self.path)
		data = GetCallbackData(args);
		callbackname = GetCallbackName(args)
		ret_msg = callbackname + "(" + data + ")"

		self.protocal_version = 'HTTP/1.1'
		self.send_response(200)
		self.send_header("Content-type", "text/html; charset=utf-8") 
		self.end_headers()
		self.wfile.write(ret_msg)

# 获得回调函数名
def GetCallbackName(args):
	ret_data = "";
	args_list = args.split('&')
	if len(args_list) >= 1:
		pos = args_list[0].find('callback=')
		if pos >= 0:
			ret_data = args_list[0][pos:]
	return ret_data

# 获得回调数据
def GetCallbackData(args):
	ret_data = "";
	args_len = len(args)

	# 长度不够
	if args_len < 31:
		ret_data = json.dumps({'code':'-1000'})

	else:
		end_pos = args.rfind('=')
		# 解析出错
		if end_pos < 0:
			ret_data = json.dumps({'code':'-2000'})
		# 没有数据
		elif end_pos <= 2:
			ret_data = json.dumps({'code':'-3000'})
		# 解析数据
		else:
			data = urllib.unquote(args[31:end_pos-2])
			ret_data = GetAnalyResult(data)

	return ret_data

# 解析数据
def GetAnalyResult(data):
	url_cws = 'http://ltpapi.xfyun.cn/v1/cws'
	url_pos = 'http://ltpapi.xfyun.cn/v1/pos'

	result = ''
	result_cws = RequestResultFromThirdPart(url_cws, data)
	result_pos = RequestResultFromThirdPart(url_pos, data)

	# 第三方返回结果失败
	if len(result_cws)==0 or len(result_pos)==0:
		result = json.dumps({'code':'-4000'})

	# 拼接第三方返回结果
	else:
		json_cws = json.loads(result_cws)
		json_pos = json.loads(result_pos)
		json_pos['data']['word'] = json_cws['data'].get('word', '')
		result = json.dumps(json_pos)

	return result

# 向第三方请求解析数据
def RequestResultFromThirdPart(url, data):
	body = urllib.urlencode({'text': data}).encode('utf-8')

	api_key = 'a6a6acb304065161247d16d759c11775'
	param = {"type": "dependent"}
	
	x_appid = '5bc00dce'
	x_param = base64.b64encode(json.dumps(param).replace(' ', '').encode('utf-8'))
	
	x_time = int(int(round(time.time() * 1000)) / 1000)
	
	x_checksum = hashlib.md5(api_key.encode('utf-8') + str(x_time).encode('utf-8') + x_param).hexdigest()
	
	x_header = {'X-Appid': x_appid,
				'X-CurTime': x_time,
				'X-Param': x_param,
				'X-CheckSum': x_checksum}
	result = ''
	req = urllib2.Request(url, body, x_header)   
	try:
		result = urllib2.urlopen(req, data=None, timeout=3)
		result = result.read()
	except Exception, e:
		result = ''

	return result
	
def StartServer():
	from BaseHTTPServer import HTTPServer
	sever = HTTPServer(("", 8080), TVRHttpServer)
	sever.serve_forever()

StartServer()