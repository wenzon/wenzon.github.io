﻿//var URL = "http://localhost:8080";
//var URL = "http://xunfeiservices1.sh.taeapp.com/"
var URL = "http://xunfeiservices2.hz.taeapp.com/";
var i=0;
function Analyze(msg){
	var settings = {
		type: "POST",
		url: URL,
		dataType:"jsonp",
		data: msg,
		jsonpCallback:"success_jsonpCallback" + (i++),
		success: function(results) {
			//console.log(results);
			OnAnalyzeCallback(results, i++);
		},
		error: function (err) {
			console.log(err);
		}
	};

	$.ajax(settings);		
}

function success_jsonpCallback(json){
	
}

function OnAnalyzeCallback(results, count){
	if(results.code != '0') {
		console.log('[ERROR]: ' + results.code);
		return;
	}

	var name = "", vert = "";
	var name_count = 0, vert_count = 0;

	var datas = results.data;
	for(var i=0; i<datas.pos.length; i++){
		var pos = datas.pos[i];
		var word = datas.word[i];

		switch(pos){
			case "v":{
				vert = word;
				vert_count++;
			}break;

			case "n":{
				name = word;
				name_count++;
			}break;

			default: break;
		}
	}

	console.log("name: " + name + ", vert: " + vert);
}

$(function () {
	var tip = document.getElementById('a');
	tip.addEventListener("click",function(){
		for(var i=0;i<100; i++)
			Analyze("空调开高点");
	});
});